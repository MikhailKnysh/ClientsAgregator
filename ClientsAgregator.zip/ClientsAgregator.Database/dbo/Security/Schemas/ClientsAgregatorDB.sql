﻿CREATE SCHEMA [ClientsAgregatorDB]
