﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetBulkStatuses]
AS

SELECT * FROM [ClientsAgregatorDB].[BulkStatus]
