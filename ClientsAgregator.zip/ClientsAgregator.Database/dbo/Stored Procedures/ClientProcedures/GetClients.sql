﻿CREATE PROCEDURE GetClients
AS
SELECT * FROM [dbo].[Clients]