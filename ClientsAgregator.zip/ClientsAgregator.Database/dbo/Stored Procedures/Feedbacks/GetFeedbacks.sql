﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetFeedbacks]
AS
SELECT * FROM [ClientsAgregatorDB].[Feedbacks]