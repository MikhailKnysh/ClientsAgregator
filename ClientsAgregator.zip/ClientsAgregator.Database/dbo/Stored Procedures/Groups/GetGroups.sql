﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetGroups]
AS
SELECT * FROM [ClientsAgregatorDB].[Groups]