﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetMeasureUnit]
AS
SELECT * FROM [ClientsAgregatorDB].[MeasureUnits]