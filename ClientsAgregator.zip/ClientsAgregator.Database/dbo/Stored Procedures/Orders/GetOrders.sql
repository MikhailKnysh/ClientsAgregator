﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetOrders]
AS
SELECT * FROM [ClientsAgregatorDB].[Orders]


