﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetProducts]
AS
SELECT * FROM [ClientsAgregatorDB].[Products]


