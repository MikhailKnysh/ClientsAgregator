﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetProductOrder]
AS
SELECT * FROM [ClientsAgregatorDB].[Product_Order]