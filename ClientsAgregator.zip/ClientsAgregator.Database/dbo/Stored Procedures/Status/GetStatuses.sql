﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetStatuses]
AS
SELECT * FROM [ClientsAgregatorDB].[Statuses]
