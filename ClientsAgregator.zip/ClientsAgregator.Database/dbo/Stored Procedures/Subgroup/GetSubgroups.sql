﻿CREATE PROCEDURE [ClientsAgregatorDB].[GetSubgroups]
AS
SELECT * FROM [ClientsAgregatorDB].[Subgroups]