﻿CREATE TABLE [ClientsAgregatorDB].[MeasureUnits] (
    [Id]    INT           IDENTITY (1, 1) NOT NULL,
    [Title] VARCHAR (255) NULL,
    CONSTRAINT [PK_MEASUREUNITS] PRIMARY KEY CLUSTERED ([Id] ASC)
);

