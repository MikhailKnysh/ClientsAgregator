﻿namespace ClientsAgregator
{
    internal class GroupModel
    {
    }
}