﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClientsAgregator_BLL.CustomModels.OrderModels
{
    public class ClientsFullNameModel
    {
        public int Id { get; set; }
        public string FullName { get; set; }
    }
}
