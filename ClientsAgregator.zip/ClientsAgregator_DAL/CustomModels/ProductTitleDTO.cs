﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClientsAgregator_DAL.CustomModels
{
    public class ProductTitleDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
