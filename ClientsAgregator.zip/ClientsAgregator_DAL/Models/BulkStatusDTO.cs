﻿
namespace ClientsAgregator_DAL.Models
{
    public class BulkStatusDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}