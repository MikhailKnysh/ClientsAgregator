﻿
namespace ClientsAgregator_DAL.Models
{
    public class GroupDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
