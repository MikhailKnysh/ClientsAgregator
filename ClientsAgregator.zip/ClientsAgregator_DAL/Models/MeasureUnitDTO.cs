﻿
namespace ClientsAgregator_DAL.Models
{
    public class MeasureUnitDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
