﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClientsAgregator_DAL.Queries
{
    public static class Options
    {
       public const string connectionString =  @"Persist Security Info=False;User ID=DevEd;Password=qqq!11;Initial Catalog=Sandbox.Test;Server=80.78.240.16";
    }
}
